<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center justify-between">
            <h2 class="font-semibold text-xl text-gray-100 leading-tight">
                {{ __('Categories') }}
            </h2>

            <a href="{{ route('categories.create') }}"
               class="inline-flex items-center px-4 py-2 bg-indigo-500 hover:bg-indigo-600 text-sm font-semibold rounded-lg text-white shadow-md transition">
                + Add Category
            </a>
        </div>
    </x-slot>

    <div class="py-8">
        <div class="max-w-5xl mx-auto sm:px-6 lg:px-8">
            @if(session('success'))
                <div class="mb-4 rounded-lg bg-green-600/20 border border-green-500/50 text-green-100 px-4 py-3 text-sm">
                    {{ session('success') }}
                </div>
            @endif
            @if(session('error'))
                <div class="mb-4 rounded-lg bg-red-600/20 border border-red-500/50 text-red-100 px-4 py-3 text-sm">
                    {{ session('error') }}
                </div>
            @endif

            <div class="bg-gray-900/80 border border-gray-800 rounded-xl shadow-xl overflow-hidden">
                <table class="min-w-full text-sm text-left text-gray-300">
                    <thead class="bg-gray-800/90 text-xs uppercase tracking-wide text-gray-400">
                        <tr>
                            <th class="px-6 py-3">Name</th>
                            <th class="px-6 py-3">Description</th>
                            <th class="px-6 py-3 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-800 bg-gray-900/60">
                        @forelse($categories as $category)
                            <tr class="hover:bg-gray-800/70 transition">
                                <td class="px-6 py-3 font-medium text-white">
                                    {{ $category->name }}
                                </td>
                                <td class="px-6 py-3 text-gray-300">
                                    {{ $category->description }}
                                </td>
                                <td class="px-6 py-3 text-right space-x-2">
                                    <a href="{{ route('categories.edit', $category) }}"
                                       class="inline-flex items-center px-3 py-1.5 text-xs font-semibold rounded-lg bg-blue-500/80 hover:bg-blue-500 text-white shadow-sm">
                                        Edit
                                    </a>
                                    <form action="{{ route('categories.destroy', $category) }}" method="POST" class="inline">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit"
                                            onclick="return confirm('Delete this category?')"
                                            class="inline-flex items-center px-3 py-1.5 text-xs font-semibold rounded-lg bg-red-500/80 hover:bg-red-500 text-white shadow-sm">
                                            Delete
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="3" class="px-6 py-6 text-center text-gray-400">
                                    No categories yet. Create one to organize your products.
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>

                <div class="px-6 py-4 border-t border-gray-800">
                    {{ $categories->links() }}
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
