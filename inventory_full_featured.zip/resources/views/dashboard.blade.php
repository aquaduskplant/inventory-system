<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-100 leading-tight">
            {{ __('Inventory Dashboard') }}
        </h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div class="bg-gray-900/80 border border-gray-800 rounded-xl p-5">
                    <h3 class="text-sm text-gray-400 mb-1">Quick Links</h3>
                    <div class="flex flex-col space-y-2">
                        <a href="{{ route('products.index') }}" class="text-indigo-300 hover:text-indigo-100 text-sm">View Products</a>
                        @if(auth()->user()->role === 'admin')
                            <a href="{{ route('categories.index') }}" class="text-indigo-300 hover:text-indigo-100 text-sm">Manage Categories</a>
                            <a href="{{ route('stock.index') }}" class="text-indigo-300 hover:text-indigo-100 text-sm">Stock History</a>
                        @endif
                    </div>
                </div>

                <div class="bg-gray-900/80 border border-gray-800 rounded-xl p-5">
                    <h3 class="text-sm text-gray-400 mb-1">Welcome</h3>
                    <p class="text-gray-300 text-sm">
                        Use this simple inventory system to manage products, track categories, and record stock in/out
                        movements. Only admins can change data — regular users can view the catalog.
                    </p>
                </div>

                <div class="bg-gray-900/80 border border-gray-800 rounded-xl p-5">
                    <h3 class="text-sm text-gray-400 mb-1">Current User</h3>
                    <p class="text-gray-200 text-sm">
                        {{ auth()->user()->name }}<br>
                        <span class="text-xs text-gray-400 uppercase tracking-wide">
                            Role: {{ auth()->user()->role }}
                        </span>
                    </p>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
