<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-100 leading-tight">
            {{ __('Stock History') }}
        </h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-6xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-gray-900/80 border border-gray-800 rounded-xl shadow-xl overflow-hidden">
                <table class="min-w-full text-sm text-left text-gray-300">
                    <thead class="bg-gray-800/90 text-xs uppercase tracking-wide text-gray-400">
                        <tr>
                            <th class="px-6 py-3">Date</th>
                            <th class="px-6 py-3">Product</th>
                            <th class="px-6 py-3">Type</th>
                            <th class="px-6 py-3">Quantity</th>
                            <th class="px-6 py-3">User</th>
                            <th class="px-6 py-3">Note</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-800 bg-gray-900/60">
                        @forelse($movements as $movement)
                            <tr>
                                <td class="px-6 py-3">
                                    {{ $movement->created_at->format('Y-m-d H:i') }}
                                </td>
                                <td class="px-6 py-3">
                                    {{ $movement->product->name ?? 'Deleted product' }}
                                </td>
                                <td class="px-6 py-3">
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold
                                        {{ $movement->movement_type === 'in'
                                            ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/40'
                                            : 'bg-red-500/10 text-red-300 border border-red-500/40' }}">
                                        {{ strtoupper($movement->movement_type) }}
                                    </span>
                                </td>
                                <td class="px-6 py-3">
                                    {{ $movement->quantity }}
                                </td>
                                <td class="px-6 py-3">
                                    {{ $movement->user->name ?? 'System' }}
                                </td>
                                <td class="px-6 py-3 text-gray-300">
                                    {{ $movement->note }}
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="6" class="px-6 py-6 text-center text-gray-400">
                                    No stock movements recorded yet.
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>

                <div class="px-6 py-4 border-t border-gray-800">
                    {{ $movements->links() }}
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
